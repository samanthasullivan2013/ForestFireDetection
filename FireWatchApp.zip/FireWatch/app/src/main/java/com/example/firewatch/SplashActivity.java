package com.example.firewatch;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {//splash page
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        int splash_Timer = 1;
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run(){
                ImageView logo = findViewById(R.id.logo);
                Animation splashing = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.splash);
                logo.startAnimation(splashing); //starts splash animation
            }
        }, splash_Timer);

        int nextPageTimer = 5000;//5 second timer
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run(){
                Intent homeIntent = new Intent(SplashActivity.this, LoginActivity.class);
                startActivity(homeIntent);
                finish();
            }
        }, nextPageTimer);
    }
}
