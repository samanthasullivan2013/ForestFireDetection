f=open('Zone1temp.json','w').close()
f=open('Zone2temp.json','w').close()
f=open('Zone3temp.json','w').close()
f=open('Zone4temp.json','w').close()


f=open('Zone1temp.json','a')
                        
f.write("[" + "\n")
f.close()
f=open('Zone2temp.json','a')
                        
f.write("[" + "\n")
f.close()
f=open('Zone3temp.json','a')
                        
f.write("[" + "\n")
f.close()
f=open('Zone4temp.json','a')
                        
f.write("[" + "\n")
f.close()


sector1= open("Zone1temp.txt","r")
sector2= open("Zone2temp.txt","r")
sector3= open("Zone3temp.txt","r")
sector4= open("Zone4temp.txt","r")

tempSec1= list(sector1.readlines())
tempSec2= list(sector2.readlines())
tempSec3= list(sector3.readlines())
tempSec4= list(sector4.readlines())

i=0

while i< len(tempSec1):
    
    f=open('Zone1temp.json','a')
    if i==len(tempSec1)-1:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec1[i])+'}'+'\n')
    else:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec1[i])+'},'+'\n')
        
    
    f.close()
    i+=1
f=open('Zone1temp.json','a')
                        
f.write(']'+'\n')
f.close()
i=0
while i< len(tempSec2):
    
    f=open('Zone2temp.json','a')
    if i==len(tempSec2)-1:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec2[i])+'}'+'\n')
    else:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec2[i])+'},'+'\n')
        
    
    f.close()
    i+=1
f=open('Zone2temp.json','a')
                        
f.write(']'+'\n')
f.close()
i=0
while i< len(tempSec3):
    
    f=open('Zone3temp.json','a')
    if i==len(tempSec3)-1:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec3[i])+'}'+'\n')
    else:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec3[i])+'},'+'\n')
        
    
    f.close()
    i+=1
f=open('Zone3temp.json','a')
                        
f.write(']'+'\n')
f.close()
i=0

while i< len(tempSec4):
    
    f=open('Zone4temp.json','a')
    if i==len(tempSec4)-1:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec4[i])+'}'+'\n')
    else:
        f.write('{'+'"'+'date'+'" '+':'+'date'+','+'"'+'Units'+'"'+':'+str(tempSec4[i])+'},'+'\n')
        
    
    f.close()
    i+=1
f=open('Zone4temp.json','a')
                        
f.write(']'+'\n')
f.close()
    
    