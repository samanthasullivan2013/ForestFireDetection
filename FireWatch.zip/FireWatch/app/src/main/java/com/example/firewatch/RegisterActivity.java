package com.example.firewatch;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity{

    protected SharedPreferences myPreferences;
    private EditText editTextName, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        myPreferences = getApplicationContext().getSharedPreferences(getString(R.string.action_sign_in), MODE_PRIVATE);
        editTextName = findViewById(R.id.edit_name);
        editTextPassword = findViewById(R.id.edit_password);

        Spinner spinner = findViewById(R.id.spinner);
        String [] ranger = {"Sector 1", "Sector 2", "Sector 3", "Sector 4"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ranger);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    public void registerOnClick(View view)
    {
        Spinner spinner = findViewById(R.id.spinner);
        String spin = spinner.getSelectedItem().toString();

        int sectorValue = Integer.parseInt(spin.substring(7));

        String User = editTextName.getText().toString();
        String Pass = editTextPassword.getText().toString();

        if (User.isEmpty() || Pass.isEmpty())
        {
            Toast toast = Toast.makeText(getApplicationContext(), R.string.invalidAttempt, Toast.LENGTH_LONG);
            toast.show();

            editTextName.setText("");
            editTextPassword.setText("");
        }
        if(User.length()<2 || Pass.length()<2)
        {
            Toast toast = Toast.makeText(getApplicationContext(), R.string.inputsTooShort, Toast.LENGTH_LONG);
            toast.show();

            editTextName.setText("");
            editTextPassword.setText("");
        }
        else{
            //String value = "My preference / some data";
            SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("my_shared_preferences", MODE_PRIVATE);

            SharedPreferences.Editor editor = sharedPreferences.edit();

            editor.putInt("sector",sectorValue);
            editor.putString("user",User);
            editor.putString("pass",Pass);

            editor.commit();

            Toast toast = Toast.makeText(getApplicationContext(),"Registered",Toast.LENGTH_SHORT);
            toast.show();

            editTextName.setText("");
            editTextPassword.setText("");

            Intent homeIntent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(homeIntent);
        }
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to exit without registering?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Intent homeIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(homeIntent);
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
