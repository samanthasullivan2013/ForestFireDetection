package com.example.firewatch.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.firewatch.R;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Random;

import static androidx.constraintlayout.widget.Constraints.TAG;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;

    private String broker = "tcp://192.168.43.105:8080";
    private String clientId;
    private MemoryPersistence persistence = new MemoryPersistence();
    private MqttClient mqttClient;
    private String topic = "class/topic";
    private ImageButton sector1respond;
    private ImageButton sector2respond;
    private ImageButton sector3respond;
    private ImageButton sector4respond;





    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);
        clientId = generateClientID();
       // mqttConnect();
        //mqttCallback();


        sector1respond=(ImageButton) root.findViewById(R.id.sector1);
        sector2respond=(ImageButton) root.findViewById(R.id.sector2);
        sector3respond=(ImageButton) root.findViewById(R.id.sector3);
        sector4respond=(ImageButton) root.findViewById(R.id.sector4);

        sector1respond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String topic = "class/test1";
                String payload = "sector1";

                ImageView image = (ImageView) sector1respond.findViewById(R.id.sector1);
                image.setImageResource(R.drawable.sector1neutral);



                Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());

                byte[] encodedPayload = new byte[0];
                try {
                    encodedPayload = payload.getBytes("UTF-8");
                    MqttMessage message = new MqttMessage(encodedPayload);
                    mqttClient.publish(topic, message);
                } catch (UnsupportedEncodingException | MqttException e) {
                    e.printStackTrace();
                }
            }
        });

        sector2respond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String topic = "class/test1";
                String payload = "sector2";

                ImageView image = (ImageView) sector2respond.findViewById(R.id.sector2);
                image.setImageResource(R.drawable.sector2neutral);


                Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());

                byte[] encodedPayload = new byte[0];
                try {
                    encodedPayload = payload.getBytes("UTF-8");
                    MqttMessage message = new MqttMessage(encodedPayload);
                    mqttClient.publish(topic, message);
                } catch (UnsupportedEncodingException | MqttException e) {
                    e.printStackTrace();
                }
            }
        });

        sector3respond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String topic = "class/test1";
                String payload = "sector3";

                ImageView image = (ImageView) sector3respond.findViewById(R.id.sector3);
                image.setImageResource(R.drawable.sector3neutral);


                Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());

                byte[] encodedPayload = new byte[0];
                try {
                    encodedPayload = payload.getBytes("UTF-8");
                    MqttMessage message = new MqttMessage(encodedPayload);
                    mqttClient.publish(topic, message);
                } catch (UnsupportedEncodingException | MqttException e) {
                    e.printStackTrace();
                }
            }
        });

        sector4respond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String topic = "class/test1";
                String payload = "sector4";

                ImageView image = (ImageView) sector4respond.findViewById(R.id.sector4);
                image.setImageResource(R.drawable.sector4neutral);


                Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());

                byte[] encodedPayload = new byte[0];
                try {
                    encodedPayload = payload.getBytes("UTF-8");
                    MqttMessage message = new MqttMessage(encodedPayload);
                    mqttClient.publish(topic, message);
                } catch (UnsupportedEncodingException | MqttException e) {
                    e.printStackTrace();
                }
            }
        });
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);



        return root;
    }




    private String generateClientID() {

        byte[] array = new byte[7];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));

        return "AndroidClient_" + generatedString;
    }



    private void mqttConnect() {
        try {
            mqttClient = new MqttClient(broker, clientId, persistence);

            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1);
            connOpts.setAutomaticReconnect(true);
            connOpts.setCleanSession(true);
            connOpts.setKeepAliveInterval(10);
            connOpts.setCleanSession(false);

            //mqttClient.setCallback((MqttCallback) this); //<-------------------------------------------this may be a problem
            Log.d(TAG, "Connecting to broker: " + broker);
            mqttClient.connect(connOpts);

            Log.d(TAG, "Connected");

            mqttClient.subscribe(topic);

        } catch (MqttException me) {
            Log.e(TAG, "msg " + me.getMessage());
            me.printStackTrace();
        }
    }


    protected void mqttCallback() {
        mqttClient.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {
                final String incomingMessage = new String(message.getPayload());
                ImageView image = (ImageView) sector1respond.findViewById(R.id.sector1);
                ImageView image2 = (ImageView) sector2respond.findViewById(R.id.sector2);
                ImageView image3 = (ImageView) sector3respond.findViewById(R.id.sector3);
                ImageView image4 = (ImageView) sector4respond.findViewById(R.id.sector4);

                final String recieved = message.toString();
                if(recieved.contains("zone:")) {
                    int zoneStart = recieved.indexOf("z") + 5;
                    int zoneEnd = recieved.indexOf(")");
                    int zone = Integer.parseInt(recieved.substring(zoneStart, zoneEnd));
                    if (zone == 1) {
                        if (recieved.contains("temp:")) {
                            Log.d(TAG, incomingMessage + "has arrived in zone 1");
                            int tempStart = recieved.indexOf("(") + 6;
                            int tempEnd = recieved.indexOf("z");
                            int temp = Integer.parseInt(recieved.substring(tempStart, tempEnd));
                            if (temp >= 10) {
                                image.setImageResource(R.drawable.sector1200predalert);
                                Log.d(TAG, temp + "image changed");
                                Log.d(TAG, "value over 70 " + incomingMessage);
                            }

                        }
                    }
                    else if (zone == 2) {
                        if (recieved.contains("temp:")) {
                            Log.d(TAG, incomingMessage + "has arrived in zone 2");
                            int tempStart = recieved.indexOf("(") + 6;
                            int tempEnd = recieved.indexOf("z");
                            int temp = Integer.parseInt(recieved.substring(tempStart, tempEnd));
                            if (temp >= 10) {
                                image2.setImageResource(R.drawable.sector2200redalert);
                                Log.d(TAG, temp + "image changed");
                                Log.d(TAG, "value over 70 " + incomingMessage);
                            }
                        }
                    }
                    else if (zone == 3) {
                        if (recieved.contains("temp:")) {
                            Log.d(TAG, incomingMessage + "has arrived in zone 3");
                            int tempStart = recieved.indexOf("(") + 6;
                            int tempEnd = recieved.indexOf("z");
                            int temp = Integer.parseInt(recieved.substring(tempStart, tempEnd));
                            if (temp >= 10) {
                                image3.setImageResource(R.drawable.sector3200predalert);
                                Log.d(TAG, temp + "image changed");
                                Log.d(TAG, "value over 70 " + incomingMessage);
                            }
                        }
                    }
                    else if (zone == 4) {
                        if (recieved.contains("temp:")) {
                            Log.d(TAG, incomingMessage + "has arrived in zone 4");
                            int tempStart = recieved.indexOf("(") + 6;
                            int tempEnd = recieved.indexOf("z");
                            int temp = Integer.parseInt(recieved.substring(tempStart, tempEnd));
                            if (temp >= 10) {
                                image4.setImageResource(R.drawable.sector4200predalert);
                                Log.d(TAG, temp + "image changed");
                                Log.d(TAG, "value over 70 " + incomingMessage);
                            }
                        }
                    }
                }
            }
            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
            }
        });
    }



}
