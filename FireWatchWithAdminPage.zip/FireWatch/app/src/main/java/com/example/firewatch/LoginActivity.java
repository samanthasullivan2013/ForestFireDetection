package com.example.firewatch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity
{
    protected SharedPreferences myPreferences;
    private EditText editTextName, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        myPreferences = getApplicationContext().getSharedPreferences(getString(R.string.action_sign_in), MODE_PRIVATE);
        editTextName = findViewById(R.id.edit_name);
        editTextPassword = findViewById(R.id.edit_password);
    }

    public void loginOnClick(View view)
    {
        String User = editTextName.getText().toString();
        String Pass = editTextPassword.getText().toString();

        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("my_shared_preferences", MODE_PRIVATE);

        String Username = sharedPreferences.getString("user","");
        String Password = sharedPreferences.getString("pass","");

        if (Username.equals(User) && Password.equals(Pass))
        {
            Intent intent = new Intent(this, MapActivity.class);
            startActivity(intent);
            Toast toast = Toast.makeText(getApplicationContext(), "Logged in", Toast.LENGTH_SHORT);
            toast.show();
        }else if(User.equals("admin")&&Pass.equals("admin123")){
            Intent intent = new Intent(this, AdminActivity.class);
            startActivity(intent);
            Toast toast = Toast.makeText(getApplicationContext(), "(Admin)Logged in", Toast.LENGTH_SHORT);
            toast.show();

        } else
        {
            Toast toast = Toast.makeText(getApplicationContext(), "Username or Password is invalid", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void registerOnClick(View view)
    {
        Intent reg = new Intent(this, RegisterActivity.class);
        startActivity(reg);
    }
}
