package com.example.firewatchv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean testButton1(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector1);
        image.setImageResource(R.drawable.sector1200porangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    public boolean testButton2(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector2);
        image.setImageResource(R.drawable.sector2200orangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    public boolean testButton3(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector3);
        image.setImageResource(R.drawable.sector3200porangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    public boolean testButton4(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector4);
        image.setImageResource(R.drawable.sector4200porangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }
}
