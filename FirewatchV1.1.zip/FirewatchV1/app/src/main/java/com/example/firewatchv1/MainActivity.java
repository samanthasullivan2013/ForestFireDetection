package com.example.firewatchv1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.Random;


public class MainActivity extends AppCompatActivity implements MqttCallback {

    public final static String TAG = "DebugMQTT";

    private String broker = "tcp://192.168.43.84:8080";
    private String clientId;
    private MemoryPersistence persistence = new MemoryPersistence();
    private MqttClient mqttClient;
    private String topic = "class/drone";
    private ImageButton btnPublish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        clientId = generateClientID();
        mqttConnect();

        btnPublish=(ImageButton) findViewById(R.id.sector1);
        btnPublish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String topic = "class/test1";
                String payload = "Hello";

                ImageView image = (ImageView) findViewById(R.id.sector1);
                image.setImageResource(R.drawable.sector1200porangealert);

                Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());

                byte[] encodedPayload = new byte[0];
                try {
                    encodedPayload = payload.getBytes("UTF-8");
                    MqttMessage message = new MqttMessage(encodedPayload);
                    mqttClient.publish(topic, message);
                } catch (UnsupportedEncodingException | MqttException e) {
                    e.printStackTrace();
                }
            }
        });

    }

    private String generateClientID() {

        byte[] array = new byte[7];
        new Random().nextBytes(array);
        String generatedString = new String(array, Charset.forName("UTF-8"));

        return "AndroidClient_" + generatedString;
    }
    public void connectionLost(Throwable cause) {
        Log.d(TAG, cause.getMessage());
    }


    public void messageArrived(String topic1, MqttMessage message) throws Exception {
        final String incomingMessage = new String(message.getPayload());
        ImageView image = (ImageView) findViewById(R.id.sector1);
        Log.d(TAG, incomingMessage);

        if (topic1.equals(topic)) {
            ImageButton buttonView = (ImageButton) findViewById(R.id.sector1);


            if(incomingMessage.equals("whatever")){
                //image.setImageResource((R.drawable.));
                Log.d(TAG, "whatever"+incomingMessage);

            }


        }
    }


    public void deliveryComplete(IMqttDeliveryToken token) {

    }

    private void mqttConnect() {
        try {
            mqttClient = new MqttClient(broker, clientId, persistence);

            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setMqttVersion(MqttConnectOptions.MQTT_VERSION_3_1);
            connOpts.setAutomaticReconnect(true);
            connOpts.setCleanSession(true);
            connOpts.setKeepAliveInterval(10);
            connOpts.setCleanSession(false);

            mqttClient.setCallback(this); //<-------------------------------------------this may be a problem
            Log.d(TAG, "Connecting to broker: " + broker);
            mqttClient.connect(connOpts);

            Log.d(TAG, "Connected");

            mqttClient.subscribe(topic);

        } catch (MqttException me) {
            Log.e(TAG, "msg " + me.getMessage());
            me.printStackTrace();
        }
    }

    //The following methods are for the purpose of testing sector button images and nothing more
    public boolean testButton1(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector1);
        image.setImageResource(R.drawable.sector1200porangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    public boolean testButton2(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector2);
        image.setImageResource(R.drawable.sector2200orangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    public boolean testButton3(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector3);
        image.setImageResource(R.drawable.sector3200porangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    public boolean testButton4(View view) {
        ImageView image = (ImageView) findViewById(R.id.sector4);
        image.setImageResource(R.drawable.sector4200porangealert);

        Log.d("LOGTAG", "changing image of sector 1 to red. image is " + image.getId());
        return true;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
